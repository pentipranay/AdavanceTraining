package com.book_1_3;

public class Book {
	private String book_titile;
	private int book_price;
	public String getBook_titile() {
		return book_titile;
	}
	public void setBook_titile(String booktitile) {
		this.book_titile = booktitile;
	}
	public int getBook_price() {
		return book_price;
	}
	public void setBook_price(int bookprice) {
		this.book_price = bookprice;
	}

}
