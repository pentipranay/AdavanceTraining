package com.book_1_3;

import java.util.Scanner;

public class TestBook {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the Book title : ");
		String booktitle=sc.nextLine();
		
		System.out.println("Enter the Book price : ");
		int price=sc.nextInt();
		sc.nextLine();
		
		Book b=new Book();
		b.setBook_titile(booktitle);
		b.setBook_price(price);
		System.out.println("Book Details");
		System.out.println("Book Title :"+b.getBook_titile());
		System.out.println("Book Price :"+b.getBook_price());
		
	}

}