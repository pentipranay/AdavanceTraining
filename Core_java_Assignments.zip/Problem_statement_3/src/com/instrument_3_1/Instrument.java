package com.instrument_3_1;


public abstract class Instrument {
	public abstract void play();
}
